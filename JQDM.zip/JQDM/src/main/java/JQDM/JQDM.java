package JQDM;

import cn.nukkit.plugin.PluginBase;
import cn.nukkit.event.Listener;
import cn.nukkit.event.player.PlayerJoinEvent;
import cn.nukkit.event.player.PlayerQuitEvent;
import cn.nukkit.event.player.PlayerDeathEvent;
import cn.nukkit.utils.Config;

public class JQDM extends PluginBase implements Listener {
   public Config config;
   
   public void onEnable(){
   			super.onEnable();
   			this.getServer().getPluginManager().registerEvents(this,this);
   			this.getLogger().info("JQDM 플러그인이 활성화 되었습니다.");
   			getDataFolder().mkdirs();
   			config=new Config(getDataFolder()+"config.yml",Config.YAML);
   			if(config.exists("use-JQDM"))
   				config.set("use-JQDM","on");
   			if(config.exists("JoinMessage"))
   				config.set("JoinMessage","§e@player 님이 들어왔습니다.");
   			if(config.exists("QuitMessage"))
   				config.set("QuitMessage","§e@player 님이 나갔습니다.");
   			if(config.exists("DeathMessage"))
   				config.set("DeathMessage","§6@player 님이 사망하였습니다.");
   			if(config.exists("OP-JoinMessage"))
   				config.set("OP-JoinMessage","§e[OP]@player 님이 들어왔습니다.");
   			if(config.exists("OP-QuitMessage"))
   				config.set("OP-QuitMessage","§e[OP]@player 님이 나갔습니다.");
   			if(config.exists("OP-DeathMessage"))
   				config.set("OP-DeathMessage","§6[OP]@player 님이 사망하였습니다.");
   			if(config.get("use-JQDM").equals("off")){
   					this.getPluginManager().disablePlugin(this);
   			}
   }
   public void onDisable(){
   			super.onDisable();
   			config.save();
   }
   
   @EventHandler
   public void onJoin(PlayerJoinEvent event){
   			String op=config.get("OP-JoinMessage").replace("@player",event.getPlayer().getName());
   			String user=config.get("JoinMessage").replace("@player",event.getPlayer().getName());
   			String message=event.getPlayer().isOp() ? op : user;
   			this.setJoinMessage(message);
   }
   @EventHandler
   public void onQuit(PlayerQuitEvent event){
   			String op=config.get("OP-QuitMessage").replace("@player",event.getPlayer().getName());
   			String user=config.get("QuitMessage").replace("@player",event.getPlayer().getName());
   			String message=event.getPlayer().isOp() ? op : user;
   			this.setQuitMessage(message);
   }
   @EventHandler
   public void onDeath(PlayerDeathEvent event){
   			String op=config.get("OP-DeathMessage").replace("@player",event.getPlayer().getName());
   			String user=config.get("DeathMessage").replace("@player",event.getPlayer().getName());
   			String message=event.getPlayer().isOp() ? op : user;
   			this.setDeathMessage(message);
   }
}